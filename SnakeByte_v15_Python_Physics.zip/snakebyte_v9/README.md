# SnakeByte v9 — Liquid Glass Python Quest v8 — 3D Python Quest

## Physics mode (v15)
SnakeByte now has two subjects in one app. Use the **Python | Physics** switch at the top of the Learn, Badges/Formulas and Me screens.
- Physics covers 1st year Diploma Engineering Physics: 9 units, 27 lessons, 162 questions, a unit check per unit and a formula sheet.
- Lessons are quiz-style (multiple choice, true/false, typed numeric answers) with 3 lives per lesson, XP, a daily goal and a shared day streak.
- Physics progress is stored separately (`snakebyte_physics_v1`), so Python progress is never affected. The chosen mode is remembered.
- Physics works fully offline. Python still needs internet the first time to load Pyodide.
- The units follow the common SBTET syllabus. Edit the `U` array in the Physics module inside `index.html` to match your college syllabus.

SnakeByte is a responsive Python-learning app packaged as an Android APK with the same web UI usable as a PWA.

## v8 upgrades
- 3D-style Python motion graphics and animated execution theatre.
- Real Pyodide Python execution with a worker timeout.
- Python examples are normalized to double-quoted strings.
- Expanded curriculum: basics, logic, loops, collections, functions, errors, OOP, JSON, async, APIs, app architecture, automation, testing and project thinking.
- Topic search across the full curriculum.
- No seeded/fake enrollment names.
- Optional Google Apps Script enrollment collector for real users.
- Admin panel can load the real enrollment list when the owner API is configured.
- Minimal 2D Python app icon.
- Android min SDK 23 for older devices such as Samsung M31-class hardware.
- GitHub Actions builds a debug APK with one workflow run.

## Real user enrollment
The app stores the enrollment locally first. To see users from different devices:
1. Create a Google Sheet.
2. Open Extensions → Apps Script and paste `backend/google-apps-script/Code.gs`.
3. Replace `CHANGE_THIS_TO_A_LONG_RANDOM_KEY` with your own random key.
4. Deploy as a Web App and allow the app to reach the deployed endpoint.
5. Paste the `/exec` URL into `USER_API_URL` in `index.html`.
6. Put the same key into `OWNER_API_KEY`.
7. Rebuild on GitHub.

The collector stores only the fields the app sends. Do not collect data you do not need.

## Important platform note
An APK is Android-only. iPhones/iPads cannot install an Android APK. The `index.html` is responsive and can be hosted as a PWA for Safari/iOS and desktop/tablet browsers.

## GitHub APK
Push the project to GitHub. Open Actions → `🚀 Build SnakeByte APK` → Run workflow. Download the generated APK from the workflow Artifacts.

## Python runtime
The in-app runner loads Pyodide from the public CDN on first use, so first execution needs internet access. The educational UI, curriculum and progress remain available locally.


## v9 UI update
- Full-width responsive layout; centered on phones and tablets instead of a narrow one-sided column.
- iOS-inspired liquid-glass cards, floating navigation, animated background orbs, translucent editor and execution overlay.
- Python examples are rendered with double-quoted string literals where safely convertible.
- Android APK remains the Android build; iPhone/iPad use the responsive web/PWA build.

## v10: minimal iOS 27 motion + one-click APK
- Sliding glass tab pill, spring screen transitions, progress ring on the run sheet. Layout and content unchanged. Previous file kept as `index_v12_backup.html`.

### Make the APK (about 4 minutes, no setup)
1. Create a new GitHub repo and upload all files from this folder (keep the `.github` folder).
2. Open the **Actions** tab, pick **Build SnakeByte APK**, press **Run workflow**. (It also runs on every push to main.)
3. When it turns green, open **Releases** on the repo home page and download `SnakeByte-Python-Quest-v10-debug.apk`. Open it on your phone and allow "Install unknown apps".


## v14: smooth iOS glass
- Removed live `backdrop-filter` from cards/inputs/buttons (the main cause of scroll jitter on Android WebView); only the floating tab bar and the compact nav bar blur now.
- Background is three pre-blurred gradients drifting on the GPU instead of animated `filter: blur()` orbs. Decorative motion pauses while scrolling.
- All animation is transform/opacity only (no layout animation); no sticky hover effects on touch; no 3D transform contexts.
- New: large-title → compact glass nav bar, jelly tab pill, spring press feedback, staggered push/pop screen transitions with Learn scroll restore, Dynamic-Island-style toast, bottom-sheet run panel, iOS switch stretch, light haptics.
- Android: hardware layer, per-frame scroll listener removed, highest display refresh rate requested.
- Previous UI kept as `index_v13_backup.html`.
